<?php
/* 
 Image Duplicates v0.2 by Nigel Whitley (c) Copyright 2013-2014
 This software is released under the terms of the GPL. For details, see license.txt.
 */
/*
 This is the "main" page. It creates the application object defined in duplicates.inc 
 before using it to show the initial page.
 */

	#Define global variables

	require_once "duplicates.inc";

	function get_checkbox_delimiter() {
		return ":";
	}


	function split_checkbox_value($checkbox_value, $checkbox_delimiter) {
		$next_checked=explode($checkbox_delimiter, $checkbox_value);
		return $next_checked;
	}

	//$checkbox_delimiter=get_checkbox_delimiter();


	$main_app=new duplicates_app();
	$main_app->show_page();


?> 

</html>
