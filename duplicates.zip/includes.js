 
/* 
 Image Duplicates v0.2 by Nigel Whitley (c) Copyright 2013-2014
 This software is released under the terms of the GPL. For details, see license.txt.
 */
/*
 Javascript files are included through this mechanism rather than directly in the html.
 It allows files to be added and removed without altering the main html.
 The loadsjsfile function dynamically loads and adds the script file.
 */
loadjsfile("convenience.js"); //convenience functions
//loadjsfile("onload.js"); //Code to be run onload
loadjsfile("ajax.js"); //Functions for making AJAX calls and handling the returned data
loadjsfile("details.js"); //Display of a large image and some associated details for that file
loadjsfile("foldergroup.js"); //Foldergroup represents an interconnected group of folders and files
loadjsfile("main.js"); //Main logic and event handling
