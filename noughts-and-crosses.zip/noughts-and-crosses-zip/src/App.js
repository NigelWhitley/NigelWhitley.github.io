import React from 'react';
import './App.css';
import Header from './components/Header';
import Container from './components/Container';

export default function App() {
	


	
	return (
        <div className="app">
            <Header className="App-header" />
			<Container />
        </div>
    )

};

