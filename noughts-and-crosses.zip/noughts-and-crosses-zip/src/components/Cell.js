import React, { useEffect, useState, useContext } from "react";
import { BoardData } from "../BoardData.mjs";
import { GameContext } from "../Game.mjs";

const Cell = props => {
    const { methods, properties } = props;
    
    const newCellValue = properties.cellValue;
    let [cellValue, setCellValue] = useState(newCellValue);

    const game = useContext(GameContext);
    //console.log("Cellvalue for cell " + properties.cellNumber);
    //console.log(newCellValue);
    //let newValue = cellValues.value;

    //const [ storedValue, setCellValue ] = useState(newValue);
    //console.log(storedValue);

    // When this component is removed
    useEffect(() => {
      return () => {
        console.log("Cleaning up...");
      }
    }, []);

    //console.log("cellValues");
    //console.log(cellValues);

    //console.log("Checking new cell value " + newCellValue);
    if (newCellValue !== cellValue) {
      //console.log("Setting new cell value to " + newCellValue);
      setCellValue(newCellValue);
    }
    let classes = "boardCell";
    let content = " ";
    if (newCellValue === BoardData.possibleValues.nought) {
      //console.log("Setting new cell value to nought");
      classes += " nought";
      content = "0";
    } else if (newCellValue === BoardData.possibleValues.cross) {
      //console.log("Setting new cell value to cross");
      classes += " cross";
      content = "X";
    }

    // When a player clicks on a cell it should be "assigned" to that player
    // (provided the cell is not currently assigned and the game is not over)
    const cellClicked = (e) => {
      if ((cellValue === BoardData.possibleValues.empty) && ( !game.isGameOver() ) ) {
        methods.fixCell(properties.cellNumber);
      }
    }

    return (
        <div 
          className={classes} 
          data-number={properties.cellNumber} 
          data-value={properties.cellValue.value} 
        >
            <div 
                className="cellOverlay"
                onClick={(e)=>cellClicked(e)}
                >
            </div>
            <span className="cellContent">{content}</span>
        </div>
      )    
}
export default Cell
