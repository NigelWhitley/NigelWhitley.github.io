import React, { useContext } from "react";
import {GameContext} from "../Game.mjs";



const Controls = (controlFunctions) => {
    const { methods } = controlFunctions;

    const game = useContext(GameContext);
    //console.log("Controls game context");
    //console.log(game);
    const player = game.player;

    const controlsClasses = "gameControls";
    const hasWon = game.isGameOver()?" won!":"";

    return (
    <div className={controlsClasses}>
      <div className="gamePanel">
        <button onClick={methods.startGame} className="gameStart">Start</button>
      </div>
      <div className="playerPanel">
        <span className="player">Player {player}</span><span className="playerWon">{hasWon}</span>
      </div>
    </div>
   )
}
export default Controls
