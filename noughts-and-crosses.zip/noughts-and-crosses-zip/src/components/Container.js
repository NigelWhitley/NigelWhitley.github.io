import React, { useReducer } from "react";
import Board from "./Board";
import Controls from "./Controls"
import {GameContext, GameData} from "../Game.mjs";

const Container = () => {

    let [game, reduceGame] = useReducer(GameData.reducer, new GameData());

    // Use the game's reducer to start a new game
    const startGame = (e) => {
        console.log("Setting initial board");
        reduceGame({action: "start"});
    }

    // Use the game's reducer to assign the cell to the current player
    const fixCell = (cellNumber) => {
        console.log("Setting initial board");
        reduceGame({action: "fixCell", cellNumber});
    }

    const methods = {
                        startGame: startGame, 
                        fixCell: fixCell, 
                    };


    return (
    <div className="container">
      <div className="inner">
        <GameContext.Provider value={game}>

            <Controls methods={methods} />
            <Board 
                methods={methods}
            />
        </GameContext.Provider>
      </div>
    </div>
   )
}
export default Container
