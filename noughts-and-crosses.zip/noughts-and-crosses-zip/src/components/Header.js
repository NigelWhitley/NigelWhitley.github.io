import React from "react"

const Header = () => {

  return (
    <header>
      <div className="page-title" >
        Noughts and Crosses
      </div>
    </header>
  )
}

export default Header
