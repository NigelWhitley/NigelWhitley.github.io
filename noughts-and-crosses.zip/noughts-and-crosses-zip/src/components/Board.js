import React, { useContext } from "react"
import Cell from "./Cell";
import { numberRange, BoardData } from "../BoardData.mjs";
import {GameContext} from "../Game.mjs";


const Board = (boardGlue) => {
    const { methods } = boardGlue;

    const game = useContext(GameContext);
    //console.log("Board - game");
    //console.log(game);
    const board = game.board;

    const getCells = () => {
        const cellRange = numberRange(1,BoardData.rowCount * BoardData.columnCount);
        //console.log("getCells");
        //console.log("Cellrange");
        //console.log(cellRange);
        // generate each cell in the game board
        return cellRange.map((value) =>(<Cell
            key={value}
            methods={methods}
            properties={getCellProperties(value)}
        />))
    }

    const getCellProperties = (cellNumber) => {
        const column = ( ( cellNumber - 1 ) % BoardData.columnCount) + 1;
        const row = ( ( cellNumber - column) / 3) + 1;

        const cellValue = board.getCellValue(BoardData.getOrdToPosition(cellNumber));
        //console.log("cellvalue");
        //console.log(cellValue);
        return {
            cellNumber: cellNumber, 
            row: row, 
            column: column, 
            cellValue: cellValue,
        };
    }

    const classes = "board";


    return (
    <div className={classes}>
        {getCells()}
    </div>
    )
}
export default Board
