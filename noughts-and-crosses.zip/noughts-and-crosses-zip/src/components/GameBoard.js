import React from 'react'

// note here need to be able to select the spaces. The css needs setting/connecting for this 

const GameBoard = (props) => {
  const [gameBoardSpace, setGameBoardSpace] = React.useState(["-", "-", "-", "-", "-", "-", "-", "-", "-"]);
  const [score, setScore] = React.useState("");
  const [spaces, setSpaces] = React.useState(spaces)
  const [winningPatterns, setWinningPatterns] = React.useState([
    [0, 4, 8],
    [0, 1, 2],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [2, 4, 6],
    [3, 4, 5],
    [6, 7, 8]
  ]);

function toggle(id) {
  setGameBoardSpace((prevGameBoard) => {
    return prevGameBoard.map((gameBoardSpace) => {
      return gameBoardSpace.id === id ? {...gameBoardSpace, on: !gameBoardSpace.on} : gameBoardSpace
    })
  })
}

const spaceElements = spaces.map(space => (
  <GameBoard
      key={space.id} 
      on={space.on} 
      toggle={() => toggle(space.id)}
  />
))


    return (
      <div>
     
      {spaceElements}
      </div>
    )
}

export default GameBoard;