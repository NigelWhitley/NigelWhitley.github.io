import { createContext } from "react";
import {BoardData} from "./BoardData.mjs";

export class GameData {
    static gameStates = {gameInitial: null, gameStarted: 0, gameOver: 1};
    // define the class fields
    gameState;
    player;
    board;

    // Create a new instance of game data
    constructor () {
        for (let [key, value] of Object.entries(GameData.initialGameData())) {
            this[key] = value;
        }
    }

    // Copy the game data.
    copy() {
        const newGame = new GameData();
        newGame.setData(this.getData());
        return newGame;
    }

    // get the data properties from this object.
    getData() {
        return {
                player: this.player, 
                gameState: this.gameState, 
                board: this.board
            };
    }

    // Set the data using the input object
    setData(gameData) {
        this.board = gameData.board;
        this.player = gameData.player
        this.gameState = gameData.gameState;
    }

    // Reducer for the game
    static reducer(game, request) {
        switch(request.action) {
            case "create":
                return new GameData();
            // For a copy it is the same data but stored in a new object
            // usually to trigger a render of a component
            case "copy":
                return game.copy();
            case "save":
                return request.game.copy();
            case "update":
                //console.log("Game reducer update");
                //console.log(request);
                const position = GameData.getOrdToPosition(request.cellNumber);
                game.setCellValue(position, request.player);
                return game;
            case "clear":
                game.clearValues();
                return game.copy();
            case "start":
                //console.log("Game reducer start");
                //const newGame = new GameData();
                game.setGameState(GameData.gameStates.gameStarted);
                game.board.clearValues();
                game.switchPlayer();
                return game.copy();
            case "setGameOver":
                game.setGameState(GameData.gameStates.gameOver);
                return game.copy();
            case "switchPlayer":
                game.switchPlayer();
                return game.copy();
            case "setPlayer":
                game.setPlayer(request.player);
                return game.copy();
            case "fixCell":
                //console.log("Game reducer fixCell");
                //console.log(request);
                //console.log(game);
                game.fixCell(request.cellNumber, game.player);
                return game.copy();
            default:
                return ;
        }
    }

    // We normally initialise a game with an empty board and player 1 to go first.
    static initialGameData() {
        return {
            player: 1, 
            gameState: GameData.gameStates.gameInitial, 
            board: BoardData.createBoard()
        }
    }

    // Assign the specified cell to the player
    fixCell(cellNumber, player) {
        //console.log("Game fixCell")
        this.board.fixCell(cellNumber, player);
        if (this.board.isGameOver(player)) {
            this.gameOver(player);
            console.log("game over");
        } else {
            //console.log("switch players");
            this.switchPlayer();
        }
    }

    // Just update the state of the game (so we know when it's over)
    setGameState(newState) {
        //console.log("setGameState");
        //console.log(newState);
        this.gameState = newState;
    }

    // Change the state of the game to "game over"
    gameOver() {
        this.setGameState(GameData.gameStates.gameOver);
    }

    // Is the game over (does a player have a winning pattern)
    isGameOver() {
        //console.log("isGameOver");
        //console.log(this.gameState);
        return (this.gameState === GameData.gameStates.gameOver);
    }

    // Set the data using the input object
    setPlayer(player) {
        this.player = player;
    }

    // Set the data using the input object
    switchPlayer() {
        this.player = (this.player === 1) ? 2: 1;
    }

}
  
export const GameContext = createContext(new GameData());

