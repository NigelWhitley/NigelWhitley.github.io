//import React, { createContext } from "react"
/* 
Nought and crosses (c) 2023
 */

	/*
	This is the object/code for managing the board, in conjunction 
	with the controls from sudokuControls. 
	The data structure is simply a rectangle of cells. 
	*/

	// This function allows creation of "multi-dimensional" arrays
	// and uses an effective base 1 instead of the "normal" JavaScript base of 0
	// e.g. createArray (10,20) will create an array of 10 21-element arrays
	//	and one empty element because Javascript arrays are zero-based.
	//      However, the zero element will be empty and therefore take no space.
	//	So arrays can be indexed like [1][2] or [10,20].
	export function createArray(arrayEnd) {
		//let arr = new Array(arrayEnd || 0),
		//	i = arrayEnd;
		let arraySize = arrayEnd + 1;
		//make_debug("Make array length " + arraySize);
		let arr = new Array(arraySize || 0);

		if (arguments.length > 1) {
			//make_debug("Make arrays");
			let args = Array.prototype.slice.call(arguments, 1);
			let eachArray = 0;
			while (eachArray++ < arrayEnd) {
				//make_debug("Make inner array " + eachArray);
				arr[eachArray] = createArray.apply(this, args);
			}
		}

		return arr;
	}

	// Generates a sequence of numbers from start to stop at intervals of step
	export const numberRange = (start, stop, step=1) =>
		Array.from(
			{ length: (stop - start) / step + 1 },
			(value, index) => start + index * step
			);

	// Define a coordinate of a cell in the board
	export class BoardPosition
	{
		constructor(aRow, aColumn) {
			this.row = aRow;
			this.column = aColumn;
		}

		// Comparison methods for this and another position
		isSameRowAs = (otherPosition) => {
			return this.row === otherPosition.row;
		}

		isSameColumnAs = (otherPosition) => {
			return this.column === otherPosition.column;
		}

		isSameAs = (otherPosition) => {
			return (this.isSameRowAs(otherPosition) && this.isSameColumnAs(otherPosition));
		}

		toString = () => {
			return this.row + ":" + this.column;
		}

		row = () => {
			return (this.row);
		}

		column = () => {
			return (this.column);
		}

		getRow = () => {
			return (this.row);
		}

		getColumn = () => {
			return (this.column);
		}

	}


	// BoardData represents the data of the noughts and crosses board.
	// Internally it is an array (rows) of arrays (column/cells).
	// Each cell holds a value (0=empty, 1=player1 or 2=player2) for that cell.
	export class BoardData {

		// The board is always 3x3 but use these rather than hard coding
		static rowCount = 3;
		static columnCount = 3;

		// winning patterns cell ids are 1 through 9 
		// ( 1 is row 1, column 1; 2 is row 1, column 2))
		static winningPatterns = [
			[1, 2, 3],
			[4, 5, 6],
			[7, 8, 9],
			[1, 4, 7],
			[2, 5, 8],
			[3, 6, 9],
			[1, 5, 9],
			[3, 5, 7],
		  ];
		
		static nought = "0";
		static cross = "X";
		static empty = " ";
		static possibleValues = {nought: 2, cross: 1, empty: 0};
		static displayValues = {2: BoardData.nought, 1: BoardData.cross, 0: BoardData.empty};

		constructor(newBoard) {
			if (typeof(newBoard) === 'undefined') {
				this.board = {};
				this.makeEmptyBoard();
			} else {
				this.board = newBoard;
			}
		}


		// Create a new cell. Used when initially building board.
		static makeCell() {
			const newCell = {};
			newCell.value = 0;
			return newCell;
		}

		// Create a new row. Used when initially building board.
		static makeRow() {
			let row = {}
			for (let column = 1; column <= BoardData.columnCount; column++) {
				row[column] = BoardData.makeCell();
			}
			return row;
		}

		// Create a new empty board.
		makeEmptyBoard() {
			this.board = {};
			for (let row = 1; row <= BoardData.rowCount; row++) {
				this.board[row] = BoardData.makeRow();
			}
			return this.board;
		}

		// Create a new board.
		static createBoard() {
			let board = new BoardData();
			board.makeEmptyBoard();
			return board;
		}

		// Create a new board and then copy the current board's data to it.
		copyBoard() {
			const board = new BoardData();
			board.setBoardData(this.getBoardData());
			return board;
		}

		// Assign (fix) a player to a cell
		fixCell(cellNumber, player) {
			const position = BoardData.getOrdToPosition(cellNumber);
			this.setCellValue(position, player);
			return this;
		}

		// Display board as string (I didn't want to use the standard toString for this)
		static asString(board) {
			let boardString = "Board : [";
			for (let row = 1; row <= BoardData.rowCount; row++) {
				boardString += " [ ";
				for (let column = 1; column <= BoardData.columnCount; column++) {
					boardString += board.board[row][column].value + " ";
				}
				boardString += "] ";
			}
			boardString += "] ";
			return boardString;
		}

		// Given the ordinal number (1 to 9) of a cell this gives the row/column coordinates.
		// Ordinal 6 gives coordinates [2,3].
		static getOrdToCoords(cell_number)
		{
			const column = ((cell_number - 1) % BoardData.rowCount) + 1;
			const row = (cell_number - column) / BoardData.rowCount;
		
			return [ row, column ];
		}
  

		// Given the ordinal number (1 to 9) of a cell this returns the position object for that cell
		// ordinal 6 gives the position for row 2, column 3.
		static getOrdToPosition(cell_number)
		{
			const column = ( (cell_number - 1) % BoardData.rowCount) + 1;
			const row = ( (cell_number - column) / BoardData.rowCount) + 1;
		
			return new BoardPosition( row, column );
		}
  

		// The actual data of the board is kept in the "board" property
		getBoardData() {
			return this.board;
		}

		// Update the actual data of the board, kept in the "board" property
		setBoardData(boardData) {
			this.board = boardData;
		}

		// Get the cell from which we can then get the value
		getCell(boardPosition) {
			//console.log("getCell boardPosition");
			//console.log(boardPosition.toString());
			const row = boardPosition.row;
			const column = boardPosition.column;
			return this.board[row][column];
		}

		// Get the value from the cell at the specified position
		getCellValue(boardPosition) {
			//console.log("getCellvalue");
			//console.log(this.getCell(boardPosition));
			const cellValue = this.getCell(boardPosition).value;
			//console.log("getCell value");
			//console.log(cellValue);
			return cellValue;
		}

		// Update the cell with the specified values
		setCell(boardPosition, values) {
			this.board[boardPosition.row][boardPosition.column] = values;
		}

		// Update the value of the cell at the specified position
		setCellValue(boardPosition, value) {
			const cell = this.getCell(boardPosition);
			cell.value = value;
			this.setCell(boardPosition, cell);
		}

		// Clear the values in every cell of the board i.e. it clears or empties the board
		clearValues() {
			//console.log("BoardData clearValues");
			for( let row=1; row <= BoardData.rowCount; row++) {

				for (let column=1; column <= BoardData.columnCount; column++) {
					const cellPosition = new BoardPosition(row, column);
					//console.log("ClearValues position");
					//console.log(cellPosition);
					this.initCell(cellPosition);
					//this.initCell(new BoardPosition(row, column));
				}
			}
			//console.log(BoardData.asString(this));
			//console.log("BoardData cleared");
		}

		// Clear the board of all values
		clearAllValues() {
			this.clearValues();
		}

		// Set the given cell to empty
		initCell(cellPosition) {
			this.setCellValue(cellPosition, BoardData.possibleValues.empty);
		}

		init() {
			this.clearValues();
		}

		// Check whether player has a winning pattern
		isGameOver(player) {

			for (let pattern of BoardData.winningPatterns) {
				const coords0 = BoardData.getOrdToPosition(pattern[0]);
				const coords1 = BoardData.getOrdToPosition(pattern[1]);
				const coords2 = BoardData.getOrdToPosition(pattern[2]);

				if (
					(this.getCellValue(coords0) === player) &&
					(this.getCellValue(coords1) === player) &&
					(this.getCellValue(coords2) === player)
				) {
					//console.log("Game over");
					return true;
				}
			}

			return false;
		}


	}
